/**
 * @fileoverview Persistence layer for INFS3201 Assignment 5.
 * Handles all database operations and file system access.
 */

const fs = require('fs/promises')
const path = require('path')
const mongodb = require('mongodb')
const crypto = require('crypto')

// ---------------------------------------------------------------------------
// Database connection
// ---------------------------------------------------------------------------

let cachedClient = undefined
let cachedDb = undefined

/**
 * Return (and cache) a connected MongoDB database instance.
 * @returns {Promise<mongodb.Db>}
 */
async function getDatabase() {
    if (cachedClient) {
        return cachedDb
    }
    cachedClient = new mongodb.MongoClient('mongodb+srv://robert:12class34@cluster0.qgtdkrd.mongodb.net/')
    await cachedClient.connect()
    cachedDb = cachedClient.db('infs3201_winter2026')
    return cachedDb
}

/**
 * Close the cached MongoDB connection.
 * @returns {Promise<void>}
 */
async function disconnectDatabase() {
    if (!cachedClient) {
        return
    }
    cachedClient.close()
}

// ---------------------------------------------------------------------------
// Employees
// ---------------------------------------------------------------------------

/**
 * Return a list of all employees.
 * @returns {Promise<Array<{ employeeId: string, name: string, phone: string }>>}
 */
async function getAllEmployees() {
    let db = await getDatabase()
    let result = db.collection('employees').find()
    return result.toArray()
}

/**
 * Find a single employee by their MongoDB ObjectId string.
 * @param {string} empId - MongoDB ObjectId as a hex string
 * @returns {Promise<{ employeeId: string, name: string, phone: string }|null>}
 */
async function findEmployee(empId) {
    let db = await getDatabase()
    return db.collection('employees').findOne({ _id: new mongodb.ObjectId(empId) })
}

/**
 * Get all shifts assigned to an employee.
 * @param {string} empId - MongoDB ObjectId as a hex string
 * @returns {Promise<Array<{ shiftId: string, date: string, startTime: string, endTime: string }>>}
 */
async function getEmployeeShifts(empId) {
    let db = await getDatabase()
    let empObjectId = new mongodb.ObjectId(empId)
    return db.collection('shifts').find({ employees: empObjectId }).toArray()
}

/**
 * Get a single shift by its shiftId field.
 * @param {string} shiftId
 * @returns {Promise<{ shiftId: string, date: string, startTime: string, endTime: string }|null>}
 */
async function findShift(shiftId) {
    let db = await getDatabase()
    return db.collection('shifts').findOne({ shiftId: shiftId })
}

/**
 * Add a new employee, auto-generating the next employeeId.
 * @param {{ name: string, phone: string }} emp
 * @returns {Promise<void>}
 */
async function addEmployeeRecord(emp) {
    let db = await getDatabase()
    let employees = db.collection('employees')
    let aggregateResult = await employees.aggregate([
        {
            $project: {
                employeeNum: {
                    $toInt: { $substr: ['$employeeId', 1, -1] }
                }
            }
        },
        { $group: { _id: null, maxEmployeeNum: { $max: '$employeeNum' } } }
    ]).toArray()
    let maxId = aggregateResult[0].maxEmployeeNum
    emp.employeeId = `E${String(maxId + 1).padStart(3, '0')}`
    await employees.insertOne(emp)
}

/**
 * Update an employee's name and phone number.
 * @param {{ employeeId: string, employeeName: string, employeePhone: string }} empDetails
 * @returns {Promise<string>} "OK" on success
 */
async function updateEmployee(empDetails) {
    let db = await getDatabase()
    let empMongoId = new mongodb.ObjectId(empDetails.employeeId)
    await db.collection('employees').updateOne(
        { _id: empMongoId },
        { $set: { name: empDetails.employeeName, phone: empDetails.employeePhone } }
    )
    return 'OK'
}

// ---------------------------------------------------------------------------
// Authentication
// ---------------------------------------------------------------------------

/**
 * Verify credentials. Returns the full user document on match, null otherwise.
 * Does NOT check the locked flag - the caller must do that.
 * @param {string} username
 * @param {string} password - Plain-text password
 * @returns {Promise<object|null>}
 */
async function checkCredentials(username, password) {
    let hashedPassword = crypto.createHash('sha256').update(password).digest('hex')
    let db = await getDatabase()
    return db.collection('users').findOne({ user: username, password: hashedPassword })
}

/**
 * Look up a user document by username.
 * @param {string} username
 * @returns {Promise<object|null>}
 */
async function getUserByUsername(username) {
    let db = await getDatabase()
    return db.collection('users').findOne({ user: username })
}

/**
 * Increment the failed-login counter and return the updated count.
 * @param {string} username
 * @returns {Promise<number>}
 */
async function incrementFailedLogins(username) {
    let db = await getDatabase()
    let result = await db.collection('users').findOneAndUpdate(
        { user: username },
        { $inc: { failedLogins: 1 } },
        { returnDocument: 'after', upsert: false }
    )
    return result ? result.failedLogins : 1
}

/**
 * Reset the failed-login counter to zero.
 * @param {string} username
 * @returns {Promise<void>}
 */
async function resetFailedLogins(username) {
    let db = await getDatabase()
    await db.collection('users').updateOne(
        { user: username },
        { $set: { failedLogins: 0 } }
    )
}

/**
 * Lock a user account. Can only be unlocked via direct DB access.
 * @param {string} username
 * @returns {Promise<void>}
 */
async function lockAccount(username) {
    let db = await getDatabase()
    await db.collection('users').updateOne(
        { user: username },
        { $set: { locked: true } }
    )
}

// ---------------------------------------------------------------------------
// 2FA tokens
// ---------------------------------------------------------------------------

/**
 * Store a 2FA token for the user, replacing any existing token.
 * The token expires in 3 minutes.
 * @param {string} username
 * @param {string} token - 6-digit numeric string
 * @returns {Promise<void>}
 */
async function store2FAToken(username, token) {
    let db = await getDatabase()
    const expiresAt = new Date(Date.now() + 3 * 60 * 1000)
    await db.collection('twofa_tokens').deleteMany({ user: username })
    await db.collection('twofa_tokens').insertOne({ user: username, token, expiresAt })
}

/**
 * Verify a 2FA token. If correct and unexpired, deletes the token and returns true.
 * @param {string} username
 * @param {string} token
 * @returns {Promise<boolean>}
 */
async function verify2FAToken(username, token) {
    let db = await getDatabase()
    let record = await db.collection('twofa_tokens').findOne({
        user: username,
        token: token,
        expiresAt: { $gt: new Date() }
    })
    if (record) {
        await db.collection('twofa_tokens').deleteOne({ _id: record._id })
        return true
    }
    return false
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

/**
 * Create a new session in the database.
 * @param {string} sessionId - UUID
 * @param {number} timeout - Validity period in seconds
 * @param {object} data - Arbitrary payload to store with the session
 * @returns {Promise<void>}
 */
async function createSession(sessionId, timeout, data) {
    let db = await getDatabase()
    const expiresAt = new Date(Date.now() + timeout * 1000)
    await db.collection('sessions').insertOne({ id: sessionId, expiry: expiresAt, data })
}

/**
 * Retrieve the data payload of a session. Returns null if the session is missing or expired.
 * @param {string} sessionId
 * @returns {Promise<object|null>}
 */
async function getSessionData(sessionId) {
    let db = await getDatabase()
    let result = await db.collection('sessions').findOne({
        id: sessionId,
        expiry: { $gt: new Date() }
    })
    return result ? result.data : null
}

/**
 * Push the session expiry forward by the given number of seconds.
 * @param {string} sessionId
 * @param {number} seconds
 * @returns {Promise<boolean>} True if a document was updated
 */
async function extendSession(sessionId, seconds) {
    let db = await getDatabase()
    let newExpiry = new Date(Date.now() + seconds * 1000)
    let result = await db.collection('sessions').updateOne(
        { id: sessionId },
        { $set: { expiry: newExpiry } }
    )
    return result.modifiedCount === 1
}

/**
 * Delete a session (used during logout).
 * @param {string} sessionId
 * @returns {Promise<void>}
 */
async function deleteSession(sessionId) {
    let db = await getDatabase()
    await db.collection('sessions').deleteOne({ id: sessionId })
}

// ---------------------------------------------------------------------------
// Security log
// ---------------------------------------------------------------------------

/**
 * Write an audit event to the security log collection.
 * @param {string} username
 * @param {string} url
 * @param {string} method - HTTP method
 * @returns {Promise<void>}
 */
async function logEvent(username, url, method) {
    let db = await getDatabase()
    await db.collection('security_log').insertOne({
        timestamp: new Date(),
        username,
        url,
        method
    })
}

// ---------------------------------------------------------------------------
// Employee documents (file system)
// ---------------------------------------------------------------------------

/** Root directory for employee documents. NOT served as a static route. */
const DOCS_DIR = path.join(__dirname, 'employee_docs')

/**
 * Create the employee_docs root directory if it does not exist.
 * @returns {Promise<void>}
 */
async function ensureDocsDir() {
    await fs.mkdir(DOCS_DIR, { recursive: true })
}

/**
 * List the filenames stored for an employee.
 * @param {string} empId - MongoDB ObjectId hex string
 * @returns {Promise<string[]>} Array of filenames
 */
async function getEmployeeDocuments(empId) {
    await ensureDocsDir()
    const empDir = path.join(DOCS_DIR, empId)
    try {
        return await fs.readdir(empDir)
    } catch (err) {
        if (err.code === 'ENOENT') {
            return []
        }
        throw err
    }
}

/**
 * Persist a document buffer to disk under the employee's directory.
 * @param {string} empId - MongoDB ObjectId hex string
 * @param {string} filename - Sanitised filename (caller's responsibility)
 * @param {Buffer} buffer - File contents
 * @returns {Promise<void>}
 */
async function saveEmployeeDocument(empId, filename, buffer) {
    await ensureDocsDir()
    const empDir = path.join(DOCS_DIR, empId)
    await fs.mkdir(empDir, { recursive: true })
    await fs.writeFile(path.join(empDir, filename), buffer)
}

/**
 * Read the contents of a stored document.
 * @param {string} empId - MongoDB ObjectId hex string
 * @param {string} filename
 * @returns {Promise<Buffer>}
 */
async function readEmployeeDocument(empId, filename) {
    const filePath = path.join(DOCS_DIR, empId, filename)
    return fs.readFile(filePath)
}

/**
 * Remove a stored document from the file system.
 * @param {string} empId
 * @param {string} filename
 * @returns {Promise<void>}
 */
async function deleteEmployeeDocument(empId, filename) {
    const filePath = path.join(DOCS_DIR, empId, filename)
    await fs.unlink(filePath)
}

module.exports = {
    getAllEmployees, findEmployee, addEmployeeRecord, updateEmployee,
    getEmployeeShifts, findShift,
    checkCredentials, getUserByUsername, incrementFailedLogins,
    resetFailedLogins, lockAccount,
    store2FAToken, verify2FAToken,
    createSession, getSessionData, extendSession, deleteSession,
    logEvent,
    getEmployeeDocuments, saveEmployeeDocument, readEmployeeDocument, deleteEmployeeDocument,
    disconnectDatabase
}
