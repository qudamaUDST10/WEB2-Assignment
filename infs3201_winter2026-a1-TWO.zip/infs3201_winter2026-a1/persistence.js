const { MongoClient } = require('mongodb')

const url = 'mongodb+srv://<we2User>:<web2pass>@cluster0.wxhglkx.mongodb.net/?appName=Cluster0'
const client = new MongoClient(url)
const dbName = 'infs3201_winter2026'

/**
 * CONNECTING
 */
async function getDb() {
    await client.connect()
    return client.db(dbName)
}

/**
 * GETTUBG ALL THE EMPLOYES
 * @returns {Promise<Array>}
 */
async function getEmployees() {
    const db = await getDb()
    return db.collection('employees').find().toArray()
}

/**
 * GET EMPLOYEE BY ID
 * @param {string} id
 * @returns {Promise<Object>}
 */
async function getEmployeeById(id) {
    const db = await getDb()
    return db.collection('employees').findOne({ employeeId: id })
}

/**
 * UPDATE EMPLOYEE
 */
async function updateEmployee(id, name, phone) {
    const db = await getDb()
    await db.collection('employees').updateOne(
        { employeeId: id },
        { $set: { name: name, phone: phone } }
    )
}

/**
 * Get shifts for one employee
 * @param {string} id
 * @returns {Promise<Array>}
 */
async function getShiftsForEmployee(id) {
    const db = await getDb()

    // Get assignments for employee
    const assignments = await db
        .collection('assignments')
        .find({ employeeId: id })
        .toArray()

    const shiftsCollection = db.collection('shifts')

    const shifts = []
    let i = 0

    while (i < assignments.length) {
        const shift = await shiftsCollection.findOne({
            shiftId: assignments[i].shiftId
        })

        if (shift) {
            shifts.push(shift)
        }

        i++
    }

    // Sort by date then startTime
    shifts.sort(function(a, b) {
        if (a.date < b.date) return -1
        if (a.date > b.date) return 1
        if (a.startTime < b.startTime) return -1
        if (a.startTime > b.startTime) return 1
        return 0
    })

    return shifts
}

module.exports = {
    getEmployees,
    getEmployeeById,
    updateEmployee,
    getShiftsForEmployee
}