const persistence = require('./persistence')

/**
 * Validate employee form
 * @param {string} name
 * @param {string} phone
 * @returns {string|null}
 */
function validateEmployee(name, phone) {
    name = name.trim()
    phone = phone.trim()

    if (name.length === 0) {
        return 'Name cannot be empty'
    }

    const regex = /^[0-9]{4}-[0-9]{4}$/
    if (!regex.test(phone)) {
        return 'Phone must be 4 digits, dash, 4 digits'
    }

    return null
}

module.exports = {
    validateEmployee
}