const prompt = require('prompt-sync')()
const business = require('./business')
const persistence = require('./persistence')

function showMenu() {
    console.log('\n1. Show all employees')
    console.log('2.Add new employee')
    console.log('3. Asign employee to shift')
    console.log('4. View  employee schedule')
    console.log('5. Exit')
}

async function main() {
    let running = true

    while (running) {
        showMenu()
        const choice = prompt('Please pick a choice> ')

        if (choice === '1') {
            const employees = await persistence.getEmployees()
            console.log('\nEmployee ID Name                 Phone')
            console.log('----------- -------------------- ---------')

            let i = 0
            while (i < employees.length) {
                console.log(
                    employees[i].employeeId.padEnd(11) +
                    employees[i].name.padEnd(21) +
                    employees[i].phone
                )
                i++
            }
        }
        else if (choice === '2') {
            const name = prompt('Enter employee name: ')
            const phone = prompt('Enter phone number: ')
            await business.addEmployee(name, phone)
            console.log('Employee added')
        }
        else if (choice === '3') {
            const empId = prompt('Enter employee ID: ')
            const shiftId = prompt('Enter shift ID: ')
            console.log(await business.assignShift(empId, shiftId))
        }
        else if (choice === '4') {
            const empId = prompt('Enter employee ID: ')
            const shifts = await persistence.getShifts()
            const assignments = await persistence.getAssignments()

            console.log('\ndate,startTime,endTime')

            let i = 0
            while (i < assignments.length) {
                if (assignments[i].employeeId === empId) {
                    let j = 0
                    while (j < shifts.length) {
                        if (shifts[j].shiftId === assignments[i].shiftId) {
                            console.log(
                                shifts[j].date + ',' +
                                shifts[j].startTime + ',' +
                                shifts[j].endTime
                            )
                        }
                        j++
                    }
                }
                i++
            }
        }
        else if (choice === '5') {
            running = false
        }
    }
}

main()
