const express = require('express')
const exphbs = require('express-handlebars')
const persistence = require('./persistence')
const business = require('./business')

const app = express()

app.engine('handlebars', exphbs.engine())
app.set('view engine', 'handlebars')

app.use(express.urlencoded({ extended: false }))
app.use(express.static('public'))

/**
 * Landing page
 */
app.get('/', async (req, res) => {
    const employees = await persistence.getEmployees()
    res.render('landing', { employees: employees })
})

/**
 * Employee details
 */
app.get('/employee/:id', async (req, res) => {
    const employee = await persistence.getEmployeeById(req.params.id)
    const shifts = await persistence.getShiftsForEmployee(req.params.id)

    res.render('employee', {
        employee: employee,
        shifts: shifts
    })
})

/**
 * Edit form
 */
app.get('/edit/:id', async (req, res) => {
    const employee = await persistence.getEmployeeById(req.params.id)
    res.render('edit', { employee: employee })
})

/**
 * Edit submission (PRG cycle)
 */
app.post('/edit/:id', async (req, res) => {
    const error = business.validateEmployee(req.body.name, req.body.phone)

    if (error) {
        return res.send(error)
    }

    await persistence.updateEmployee(
        req.params.id,
        req.body.name.trim(),
        req.body.phone.trim()
    )

    res.redirect('/')
})

app.listen(3000)