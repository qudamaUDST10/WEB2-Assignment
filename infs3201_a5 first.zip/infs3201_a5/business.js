/**
 * @fileoverview Business logic layer for INFS3201 Assignment 5.
 * All application rules live here; no HTTP or DB details.
 */

const crypto = require('crypto')
const persistence = require('./persistence.js')
const emailSystem = require('./emailSystem.js')

/** Number of failed logins before a suspicious-activity email is sent. */
const SUSPICIOUS_THRESHOLD = 3

/** Number of failed logins before the account is locked. */
const LOCK_THRESHOLD = 10

/** Session duration in seconds. */
const SESSION_DURATION = 5 * 60

// ---------------------------------------------------------------------------
// Employee helpers
// ---------------------------------------------------------------------------

/**
 * Return a list of all employees.
 * @returns {Promise<Array<{ employeeId: string, name: string, phone: string }>>}
 */
async function getAllEmployees() {
    return persistence.getAllEmployees()
}

/**
 * Return a single employee by ID.
 * @param {string} id - MongoDB ObjectId hex string
 * @returns {Promise<object|null>}
 */
async function getEmployee(id) {
    return persistence.findEmployee(id)
}

/**
 * Return the shifts for an employee.
 * @param {string} empId
 * @returns {Promise<Array>}
 */
async function getEmployeeShifts(empId) {
    return persistence.getEmployeeShifts(empId)
}

/**
 * Add a new employee record.
 * @param {{ name: string, phone: string }} emp
 * @returns {Promise<void>}
 */
async function addEmployeeRecord(emp) {
    return persistence.addEmployeeRecord(emp)
}

/**
 * Update an employee's editable fields.
 * @param {{ employeeId: string, employeeName: string, employeePhone: string }} emp
 * @returns {Promise<string>} "OK" on success
 */
async function updateEmployee(emp) {
    return persistence.updateEmployee(emp)
}


// ---------------------------------------------------------------------------
// Session management
// ---------------------------------------------------------------------------

/**
 * Check whether a session ID represents a valid, unexpired session.
 * @param {string} sessionId
 * @returns {Promise<boolean>}
 */
async function validSession(sessionId) {
    let result = await persistence.getSessionData(sessionId)
    return result !== null
}

/**
 * Extend a session and return the extension period in seconds.
 * @param {string} sessionId
 * @returns {Promise<number>} The extension in seconds
 */
async function extendSession(sessionId) {
    await persistence.extendSession(sessionId, SESSION_DURATION)
    return SESSION_DURATION
}

/**
 * Destroy a session (logout).
 * @param {string} sessionId
 * @returns {Promise<void>}
 */
async function endSession(sessionId) {
    await persistence.deleteSession(sessionId)
}

// ---------------------------------------------------------------------------
// Security log
// ---------------------------------------------------------------------------

/**
 * Write a request to the security audit log, resolving the username from the
 * session if one is present.
 * @param {string|undefined} sessionId
 * @param {string} url
 * @param {string} method
 * @returns {Promise<void>}
 */
async function logEvent(sessionId, url, method) {
    let username = ''
    if (sessionId) {
        let sessionData = await persistence.getSessionData(sessionId)
        if (sessionData) {
            username = sessionData.user
        }
    }
    await persistence.logEvent(username, url, method)
}



/**
 * Cleanly disconnect from the database.
 * @returns {Promise<void>}
 */
async function disconnectDatabase() {
    return persistence.disconnectDatabase()
}

module.exports = {
    getAllEmployees, getEmployee, getEmployeeShifts, addEmployeeRecord, updateEmployee,
    
    validSession, extendSession, endSession,
    logEvent,
    
    disconnectDatabase
}
