/**
 * @fileoverview 
 * Handles HTTP routing and delegates all logic to the business layer.
 */

const express = require('express')
const handlebars = require('express-handlebars')
const cookieParser = require('cookie-parser')
const multer = require('multer')
const business = require('./business.js')

const app = express()

// ---------------------------------------------------------------------------
// View engine
// ---------------------------------------------------------------------------
app.set('view engine', 'hbs')
app.set('views', __dirname + '/template')
app.engine('hbs', handlebars.engine())

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------
app.use('/public', express.static(__dirname + '/static'))
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())

// Multer: store uploads in memory so we can inspect before writing to disk
const upload = multer({ storage: multer.memoryStorage() })

// ---------------------------------------------------------------------------
// Audit logging (runs on every request)
// ---------------------------------------------------------------------------
app.use(async (req, res, next) => {
    let sessionId = req.cookies.session
    await business.logEvent(sessionId, req.url, req.method)
    next()
})

// ---------------------------------------------------------------------------
// Public routes (no authentication required)
// ---------------------------------------------------------------------------

app.get('/login', (req, res) => {
    let message = req.query.msg || ''
    res.render('login', { message, layout: undefined })
})

/**
 * Step 1 of login: validate username + password, send 2FA code.
 */
app.post('/login', async (req, res) => {
    let username = (req.body.username || '').trim()
    let password = req.body.password || ''

    let outcome = await business.checkLoginCredentials(username, password)

    if (outcome.result === 'locked') {
        res.redirect('/login?msg=Account is locked. Please contact your administrator.')
        return
    }

    if (outcome.result === 'invalid') {
        res.redirect('/login?msg=Invalid username or password.')
        return
    }

    // Credentials accepted – send user to 2FA page.
    // We use a short-lived cookie containing only the username (not a real session).
    res.cookie('pending2fa', username, { maxAge: 3 * 60 * 1000, httpOnly: true })
    res.redirect('/login/2fa')
})





app.get('/logout', async (req, res) => {
    let sessionId = req.cookies.session
    if (sessionId) {
        await business.endSession(sessionId)
    }
    res.clearCookie('session')
    res.redirect('/login')
})

// ---------------------------------------------------------------------------
// Authentication guard (applies to all routes below)
// ---------------------------------------------------------------------------
app.use(async (req, res, next) => {
    let sessionId = req.cookies.session
    if (!sessionId) {
        res.redirect('/login?msg=You must be logged in.')
        return
    }
    let valid = await business.validSession(sessionId)
    if (!valid) {
        res.redirect('/login?msg=Your session has expired.')
        return
    }
    let validTime = await business.extendSession(sessionId)
    res.cookie('session', sessionId, { maxAge: validTime * 1000, httpOnly: true })
    next()
})

// ---------------------------------------------------------------------------
// Protected routes
// ---------------------------------------------------------------------------

app.get('/', async (req, res) => {
    let empList = await business.getAllEmployees()
    res.render('landing', { empList, layout: undefined })
})

app.get('/employee/:eid', async (req, res) => {
    let employeeDetails = await business.getEmployee(req.params.eid)
    if (!employeeDetails) {
        res.status(404).send('Employee not found.')
        return
    }
    let shifts = await business.getEmployeeShifts(req.params.eid)
    for (let s of shifts) {
        s.startEarly = s.startTime < '12:00'
        s.endEarly = s.endTime < '12:00'
    }
    let documents = await business.getEmployeeDocuments(req.params.eid)
    let docsFull = documents.length >= 5
    let uploadMsg = req.query.msg || ''
    res.render('single_employee', { employeeDetails, shifts, documents, docsFull, uploadMsg, layout: undefined })
})

app.get('/edit/:eid', async (req, res) => {
    let employeeDetails = await business.getEmployee(req.params.eid)
    if (!employeeDetails) {
        res.status(404).send('Employee not found.')
        return
    }
    res.render('edit_employee', { employeeDetails, layout: undefined })
})

app.post('/update-employee', async (req, res) => {
    let employeeId = (req.body.id || '').trim()
    let employeeName = (req.body.name || '').trim()
    let employeePhone = (req.body.phone || '').trim()

    if (!employeeName || !employeePhone) {
        res.send('Form inputs invalid. Name and phone are required.')
        return
    }

    let result = await business.updateEmployee({ employeeId, employeeName, employeePhone })
    if (result === 'OK') {
        res.redirect('/')
    } else {
        res.send('Error updating employee record.')
    }
})



// ---------------------------------------------------------------------------
// Start server
// ---------------------------------------------------------------------------
app.listen(8000, () => {
    console.log('Server running on http://localhost:8000')
})
