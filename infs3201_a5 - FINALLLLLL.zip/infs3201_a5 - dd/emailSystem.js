/**
 * @fileoverview Email system module for INFS3201 Assignment 5.
 * This module simulates an email system using console.log output.
 * The interface is designed to be swappable with a real email provider
 * (e.g. Nodemailer + SMTP) without any changes to the callers.
 */

/**
 * Send a generic email message.
 * @param {string} to - Recipient email address
 * @param {string} subject - Email subject line
 * @param {string} body - Plain-text email body
 * @returns {Promise<boolean>} True if the email was sent successfully
 */
async function sendEmail(to, subject, body) {
    // In production, replace this block with real SMTP / SES / Mailgun logic.
    console.log('========== EMAIL ==========')
    console.log(`TO:      ${to}`)
    console.log(`SUBJECT: ${subject}`)
    console.log(`BODY:\n${body}`)
    console.log('===========================')
    return true
}

/**
 * Send a 2FA verification code to the user.
 * @param {string} to - Recipient email address
 * @param {string} code - The 6-digit 2FA code
 * @returns {Promise<boolean>} True if the email was sent successfully
 */
async function send2FACode(to, code) {
    const subject = 'Your login verification code'
    const body =
        `Hello,\n\n` +
        `Your one-time verification code is: ${code}\n\n` +
        `This code expires in 3 minutes. Do not share it with anyone.\n\n` +
        `If you did not attempt to log in, please contact support immediately.`
    return sendEmail(to, subject, body)
}

/**
 * Notify the user that suspicious login activity has been detected on their account.
 * @param {string} to - Recipient email address
 * @returns {Promise<boolean>} True if the email was sent successfully
 */
async function sendSuspiciousActivityAlert(to) {
    const subject = 'Suspicious login activity on your account'
    const body =
        `Hello,\n\n` +
        `We have detected multiple failed login attempts on your account.\n\n` +
        `If this was not you, please contact your administrator immediately.\n\n` +
        `Your account will be locked after further failed attempts.`
    return sendEmail(to, subject, body)
}

/**
 * Notify the user that their account has been locked due to too many failed attempts.
 * @param {string} to - Recipient email address
 * @returns {Promise<boolean>} True if the email was sent successfully
 */
async function sendAccountLockedNotification(to) {
    const subject = 'Your account has been locked'
    const body =
        `Hello,\n\n` +
        `Your account has been locked due to too many failed login attempts.\n\n` +
        `Please contact your administrator to have your account unlocked.`
    return sendEmail(to, subject, body)
}

module.exports = {
    sendEmail,
    send2FACode,
    sendSuspiciousActivityAlert,
    sendAccountLockedNotification
}
