/**
 * @fileoverview Business logic layer for INFS3201 Assignment 5.
 * All application rules live here; no HTTP or DB details.
 */

const crypto = require('crypto')
const persistence = require('./persistence.js')
const emailSystem = require('./emailSystem.js')

/** Number of failed logins before a suspicious-activity email is sent. */
const SUSPICIOUS_THRESHOLD = 3

/** Number of failed logins before the account is locked. */
const LOCK_THRESHOLD = 10

/** Session duration in seconds. */
const SESSION_DURATION = 5 * 60

// ---------------------------------------------------------------------------
// Employee helpers
// ---------------------------------------------------------------------------

/**
 * Return a list of all employees.
 * @returns {Promise<Array<{ employeeId: string, name: string, phone: string }>>}
 */
async function getAllEmployees() {
    return persistence.getAllEmployees()
}

/**
 * Return a single employee by ID.
 * @param {string} id - MongoDB ObjectId hex string
 * @returns {Promise<object|null>}
 */
async function getEmployee(id) {
    return persistence.findEmployee(id)
}

/**
 * Return the shifts for an employee.
 * @param {string} empId
 * @returns {Promise<Array>}
 */
async function getEmployeeShifts(empId) {
    return persistence.getEmployeeShifts(empId)
}

/**
 * Add a new employee record.
 * @param {{ name: string, phone: string }} emp
 * @returns {Promise<void>}
 */
async function addEmployeeRecord(emp) {
    return persistence.addEmployeeRecord(emp)
}

/**
 * Update an employee's editable fields.
 * @param {{ employeeId: string, employeeName: string, employeePhone: string }} emp
 * @returns {Promise<string>} "OK" on success
 */
async function updateEmployee(emp) {
    return persistence.updateEmployee(emp)
}

// ---------------------------------------------------------------------------
// Login step 1 – credentials check + 2FA dispatch
// ---------------------------------------------------------------------------

/**
 * Validate the username/password combination and, if correct, generate and
 * email a 6-digit 2FA code.  Returns an object describing the outcome.
 *
 *
 * @param {string} username
 * @param {string} password - Plain-text password
 * @returns {Promise<{ result: string, username?: string }>}
 */
async function checkLoginCredentials(username, password) {
    // Fetch the user record first so we can check the locked flag
    let userRecord = await persistence.getUserByUsername(username)

    if (!userRecord) {
        // User does not exist – increment would be a no-op, just return invalid
        return { result: 'invalid' }
    }

    if (userRecord.locked) {
        return { result: 'locked' }
    }

    let credentialMatch = await persistence.checkCredentials(username, password)

    if (!credentialMatch) {
        let newCount = await persistence.incrementFailedLogins(username)

        if (newCount >= LOCK_THRESHOLD) {
            await persistence.lockAccount(username)
            await emailSystem.sendAccountLockedNotification(userRecord.email || username)
        } else if (newCount >= SUSPICIOUS_THRESHOLD) {
            await emailSystem.sendSuspiciousActivityAlert(userRecord.email || username)
        }

        return { result: 'invalid' }
    }

    // Credentials matched – reset counter, generate 2FA code
    await persistence.resetFailedLogins(username)
    const code = String(Math.floor(100000 + Math.random() * 900000))
    await persistence.store2FAToken(username, code)
    await emailSystem.send2FACode(userRecord.email || username, code)

    return { result: 'ok', username }
}

// ---------------------------------------------------------------------------
// Login step 2 – 2FA verification + session creation
// ---------------------------------------------------------------------------

/**
 * Verify a 2FA token.  If valid, create a full session and return the session
 * details.  Returns null if the token is wrong or expired.
 *
 * @param {string} username
 * @param {string} token - 6-digit code entered by the user
 * @returns {Promise<{ sessionId: string, duration: number }|null>}
 */
async function verify2FAAndStartSession(username, token) {
    let valid = await persistence.verify2FAToken(username, token)
    if (!valid) {
        return null
    }
    const sessionId = crypto.randomUUID()
    await persistence.createSession(sessionId, SESSION_DURATION, { user: username })
    return { sessionId, duration: SESSION_DURATION }
}


/**
 * Check whether a session ID represents a valid, unexpired session.
 * @param {string} sessionId
 * @returns {Promise<boolean>}
 */
async function validSession(sessionId) {
    let result = await persistence.getSessionData(sessionId)
    return result !== null
}

/**
 * Extend a session and return the extension period in seconds.
 * @param {string} sessionId
 * @returns {Promise<number>} The extension in seconds
 */
async function extendSession(sessionId) {
    await persistence.extendSession(sessionId, SESSION_DURATION)
    return SESSION_DURATION
}

/**
 * Destroy a session (logout).
 * @param {string} sessionId
 * @returns {Promise<void>}
 */
async function endSession(sessionId) {
    await persistence.deleteSession(sessionId)
}

// ---------------------------------------------------------------------------
// Security log
// ---------------------------------------------------------------------------

/**
 * Write a request to the security audit log, resolving the username from the
 * session if one is present.
 * @param {string|undefined} sessionId
 * @param {string} url
 * @param {string} method
 * @returns {Promise<void>}
 */
async function logEvent(sessionId, url, method) {
    let username = ''
    if (sessionId) {
        let sessionData = await persistence.getSessionData(sessionId)
        if (sessionData) {
            username = sessionData.user
        }
    }
    await persistence.logEvent(username, url, method)
}

// ---------------------------------------------------------------------------
// Employee documents
// ---------------------------------------------------------------------------

/** Maximum number of documents per employee. */
const MAX_DOCS = 5

/** Maximum file size in bytes (2 MB). */
const MAX_FILE_SIZE = 2 * 1024 * 1024

/**
 * Return the list of document filenames for an employee.
 * @param {string} empId
 * @returns {Promise<string[]>}
 */
async function getEmployeeDocuments(empId) {
    return persistence.getEmployeeDocuments(empId)
}

/**
 * Validate and save an uploaded employee document.
 *
 *
 * @param {string} empId
 * @param {{ originalname: string, mimetype: string, size: number, buffer: Buffer }} file - Multer file object
 * @returns {Promise<{ result: string }>}
 */
async function uploadEmployeeDocument(empId, file) {
    if (file.mimetype !== 'application/pdf') {
        return { result: 'not_pdf' }
    }

    if (file.size > MAX_FILE_SIZE) {
        return { result: 'too_large' }
    }

    let existing = await persistence.getEmployeeDocuments(empId)
    if (existing.length >= MAX_DOCS) {
        return { result: 'too_many' }
    }

    // Sanitise the filename to prevent path traversal
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_')
    await persistence.saveEmployeeDocument(empId, safeName, file.buffer)

    return { result: 'ok' }
}

/**
 * Serve a document: read it from disk and return the buffer.
 * Returns null if the employee or file does not exist.
 * @param {string} empId
 * @param {string} filename
 * @returns {Promise<Buffer|null>}
 */
async function getEmployeeDocumentBuffer(empId, filename) {
    let existing = await persistence.getEmployeeDocuments(empId)
    // Validate the filename is one that actually exists (prevents path traversal)
    if (!existing.includes(filename)) {
        return null
    }
    try {
        return await persistence.readEmployeeDocument(empId, filename)
    } catch (err) {
        return null
    }
}

/**
 * Delete a document for an employee.
 * Returns false if the file did not exist.
 * @param {string} empId
 * @param {string} filename
 * @returns {Promise<boolean>}
 */
async function deleteEmployeeDocument(empId, filename) {
    let existing = await persistence.getEmployeeDocuments(empId)
    if (!existing.includes(filename)) {
        return false
    }
    await persistence.deleteEmployeeDocument(empId, filename)
    return true
}

/**
 * Cleanly disconnect from the database.
 * @returns {Promise<void>}
 */
async function disconnectDatabase() {
    return persistence.disconnectDatabase()
}

module.exports = {
    getAllEmployees, getEmployee, getEmployeeShifts, addEmployeeRecord, updateEmployee,
    checkLoginCredentials, verify2FAAndStartSession,
    validSession, extendSession, endSession,
    logEvent,
    getEmployeeDocuments, uploadEmployeeDocument, getEmployeeDocumentBuffer, deleteEmployeeDocument,
    disconnectDatabase
}
